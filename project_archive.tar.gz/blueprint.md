# Project Blueprint

## Overview

A simple React application that suggests a random lunch option from a predefined list.

## Features

*   Displays a title "오늘 점심은 뭐 먹지" (What should I eat for lunch today?).
*   A button to generate a random lunch suggestion.
*   Displays the randomly selected lunch option.

## Styling

*   Minimal and clean design.
*   Centered layout.
